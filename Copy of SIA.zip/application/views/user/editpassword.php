<h3>Ganti Password</h3>
<form action="<?php echo site_url('User/changePass');?>" method="post">
<input type="password" name="password" placeholder="Ketik Password Pengganti" class="form-control"><br>
<button type="submit" class="btn btn-primary">Ganti Password</button>
</form>