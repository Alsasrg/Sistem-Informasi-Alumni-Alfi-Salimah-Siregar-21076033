<h3>Selamat Datang di <?php echo web_info('nama_web');?></h3>

<div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#tab_1" data-toggle="tab">Prakata</a></li>
              <li><a href="#tab_2" data-toggle="tab">Petunjuk</a></li>
              <li><a href="#tab_3" data-toggle="tab">Support</a></li>
              
              <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1">
                <b><?php echo web_info('nama_web');?></b><br>

                Selamat memakai aplikasi ini semoga bermanfaat
                <br><br>
                <br><a href="http://nursyamsi.net">Nursyamsi</a>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2">
                Sebelum menggunakan aplikasi ini harap isi terlebih dahulu jenis pekerjaan di menu pengaturan->Manage Jenis Pekerjaan

               <br> <b>Fitur Aplikasi</b><br>
                <b><ol>
                  <li>Manage Lulusan Terdaftar</li>
                  <li>Pemetaan Lulusan per angkatan</li>
                  <li>Pemetaan Lulusan berdasarkan Jenis Kelamin</li>
                  <li>Pemetaan Lulusan Angkatan berdasarkan jenis kelamin</li>
                  <li>Statistik Lulusan berdasarkan angkatan</li>
                  <li>Statistik Lulusan berdasarkan pekerjaan</li>
                  <li>Post Berita sebagai informasi untuk alumni</li>
                </ol></b>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3">
                Jika anda mengalami masalah dalam penggunaan aplikasi ini, anda bisa menghubungi developer aplikasi ini di<br>
                            <a class="twitter-timeline"  href="https://twitter.com/info_aji" data-widget-id="279265286195122177">Tweets by @info_aji</a>
            <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
          
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
